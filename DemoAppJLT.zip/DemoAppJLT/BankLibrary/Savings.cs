﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLibrary
{
    public class Savings : Bank
    {
        public Savings()
        {

        }
        public Savings(string accname, double amt) : base(accname, amt)
        {

        }

       
        public override void Withdraw(double amount)
        {
            if((Balance - amount) >= 0)
            {
                Balance -= amount;
            }
            else
            {
                throw new BalanceException("Balance is not Sufficent");
            }
        }
    }
}
