﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLibrary
{
    public class Bank
    {
        //fields
        //methods
         
        private string accHolderName;
        private double balance;

        //property - getter and setter
        //field name - camelCase
        //property - PascalCase

        public string AccHolderName
        {
            get { return accHolderName; }
            set { accHolderName = value;  }
        }

        public double Balance
        {
            get { return balance; }
            protected set { balance = value;  }
        }

        public Bank() {
            Balance = 1000;
        }

        public Bank(string name,double amount)
        {
            AccHolderName = name;
            Balance = amount;
        }

        public void Deposit(double amount) {
            balance += amount;
        }

        public virtual void Withdraw(double amount) {
            balance -= amount;
        }

        public override string ToString()
        {
            // return base.ToString(); by using base we can call
            //  return "AccountHolderName = " + AccHolderName + " Balance" + Balance;

            //Placeholder
            //return string.Format("AccountHolderName = {0} Balance = {1}", AccHolderName, Balance);

            //String interpolation
            return string.Format($"AccountHolderName = {AccHolderName} Balance = {Balance}");

        }
    }
}
