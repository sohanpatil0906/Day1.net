﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankLibrary;

namespace DemoAppJLT
{
    class Program
    {
        static void Main(string[] args)
        {
            Savings savings = new Savings();
            Console.WriteLine(savings);

            Savings savings1 = new Savings("ABCDE",30000);
            Console.WriteLine(savings1);

            
            

            try
            {
                savings1.Withdraw(50000);
            }
            catch (BalanceException ex)
            {
                Console.WriteLine(ex.Message); 
            }

            Console.ReadLine();
        }
    }
}



//        Bank bank = new Bank();
//          bank.AccHolderName = "Sohan";
//bank.Balance = 10000;

//            Console.WriteLine(bank);

// bank.Deposit(15000);
// Console.WriteLine(bank);

//bank.Withdraw(5000);
//  Console.WriteLine(bank);

//    Console.WriteLine("---------------------------------");
//      Bank bank1 = new Bank("ABCD" , 10000);
//        Console.WriteLine(bank1);

//polymorphism
// Object obj = new Object();
//   Console.WriteLine(obj);

//          obj = bank1;
//           Console.WriteLine(obj);
